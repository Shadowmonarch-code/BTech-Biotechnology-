// Register GSAP ScrollTrigger
gsap.registerPlugin(ScrollTrigger);

// 1. Initial Load Animations
window.addEventListener('load', () => {
    const tl = gsap.timeline();
    
    tl.from(".navbar", { y: -100, opacity: 0, duration: 1, ease: "power4.out" })
      .from(".hero-text-area h1", { x: -100, opacity: 0, duration: 0.8 }, "-=0.5")
      .from(".image-orb", { scale: 0, opacity: 0, duration: 1, ease: "back.out(1.7)" }, "-=0.5")
      .from(".cta-group .btn", { y: 20, opacity: 0, stagger: 0.2 }, "-=0.5");
});

// 2. Fixed Header on Scroll
window.addEventListener('scroll', () => {
    const header = document.querySelector('#header');
    if (window.scrollY > 100) {
        header.classList.add('scrolled');
    } else {
        header.classList.remove('scrolled');
    }
});

// 3. Custom Cursor Movement
const cursor = document.querySelector('.cursor');
const follower = document.querySelector('.cursor-follower');

document.addEventListener('mousemove', (e) => {
    gsap.to(cursor, { x: e.clientX, y: e.clientY, duration: 0 });
    gsap.to(follower, { x: e.clientX - 12, y: e.clientY - 12, duration: 0.3 });
});

// 4. Typing Animation
const typedTextSpan = document.getElementById("typed");
const textArray = ["Biotechnology Student", "Bioinformatics Enthusiast", "Bong Coder Creator", "Digital Artist"];
let textArrayIndex = 0;
let charIndex = 0;

function type() {
    if (charIndex < textArray[textArrayIndex].length) {
        typedTextSpan.textContent += textArray[textArrayIndex].charAt(charIndex);
        charIndex++;
        setTimeout(type, 100);
    } else {
        setTimeout(erase, 2000);
    }
}

function erase() {
    if (charIndex > 0) {
        typedTextSpan.textContent = textArray[textArrayIndex].substring(0, charIndex - 1);
        charIndex--;
        setTimeout(erase, 50);
    } else {
        textArrayIndex++;
        if (textArrayIndex >= textArray.length) textArrayIndex = 0;
        setTimeout(type, 500);
    }
}
type();

// 5. Magnetic Button Effect
const magnets = document.querySelectorAll('.magnetic');
magnets.forEach((mag) => {
    mag.addEventListener('mousemove', (e) => {
        const position = mag.getBoundingClientRect();
        const x = e.pageX - position.left - position.width / 2;
        const y = e.pageY - position.top - position.height / 2;
        gsap.to(mag, { x: x * 0.3, y: y * 0.3, duration: 0.3 });
    });
    mag.addEventListener('mouseleave', () => {
        gsap.to(mag, { x: 0, y: 0, duration: 0.3 });
    });
});

// 6. AOS Initialization
AOS.init({
    duration: 1000,
    once: false,
    mirror: true
});

// 7. Parallax Effect for Hero Image
gsap.to(".image-orb", {
    yPercent: -20,
    ease: "none",
    scrollTrigger: {
        trigger: ".hero",
        scrub: true
    }
});